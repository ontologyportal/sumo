%-------------------------------
% CELT NOUN PHRASES TRANSLATED USING GULP
%-------------------------------

% Copyright � 2002 Teknowledge Corporation
% This software released under the GNU Public License <http://www.gnu.org/copyleft/gpl.html>.

% Test parsing with test_all_NP to test stored parse tests.
% Test generation of noun phrases with a specified length and
% number of words with test_gen_1 ... to test_gen_all.

% William R. Murray

:- style_check(-singleton).      % no singletons warnings
:- style_check(-discontiguous).  % allows more creative predicate placement

:-write_herald(', definite clause grammar rules for parsing noun phrases.').

%-------------------------------
% DCG RULES FOR CELT NOUN PHRASES
%-------------------------------

% FEATURES used in DCG rules

/*

syn,    Syntactic Features--

case,   is the case of a noun phrase, one of [nominative,accusative]
num,    is the number of a noun phrase, one of [singular, plural]
gender, is the gender of a noun phrase, one of [male,female]. Use _ if neuter.
act,    is the action of a predicate, one of the verb roots in the lexicon.
vcat,   is the verb category, either 'copula' or a 3-element list like [intransitive,transitive,ditransitive] or [no,transitive,no]
gcat,   is the gap category, either 'empty' if there is none, or one of the same categories as for nouns [person,thing,time]
gap,    is the relative pronoun that signals the gap construction (e.g., 'who' in a relative sentences; e.g., 'what' in a query)
rel,    is whether or not the grammatical category is inside a relative sentence or not, one of [yes,no] *
max,    is the maximum number of repeated consecutive structures, which currently only applies to adjuncts.
ncat,   is the noun category for the head noun in a noun phrase, one of [person,thing,time].
advp,   is the adverbial preposition or adverb used in an adjunct (e.g., 'inside' in 'inside the house', or 'slowly' in 'slowly').
role,   is the role this speech act plays, one of [assertion, query, command] for sentences, questions, or imperatives respectively.
det,    is the determiner for the head of this noun phrase (e.g., the, a, which, what...)
aux,    is 'yes' if an auxiliary such as 'does' is present, and 'no', if no axiliary is present
qvars,  is a list of query variables to be found in a query (e.g., [?who,?what]). It is [] for assertions and yes/no queries.
reply,  is the full-sentence reply for a query using the qvars as place holders for answers to be determined

* - regardless of whether a gap can be used in the construction, instead this just determines whether a relative sentence
may be embedded inside this structure, if rel is 'yes' then the construction is already inside a relative sentence and another
may not be used. If rel is 'no' then the construction is top-level or otherwise not inside a relative sentence and may allow
one to be used internally, i.e., we know that it will not be doubly-embedded. E.g., rel can be 'yes' inside a predicate inside
a relative sentence even if the gap construction is to be filled in elsewhere, i.e., in the subject, as in this sentence: 'The
boy sees who gives the book to the man.' where the gap 'who' is used in the embedded sentence 'gives the book to the man' in
the subject position, so the gap is empty for the predicate 'gives the book to the man' even though rel is 'yes'.

sem,    Semantic Features--

 neg,    can be used for any part of speech, to indicate that is negated (yes) or not (no). The typical value is 'no'.

 of predicates,

pred, --see verb phrases--    
subj, --see verb phrases--       
dobj, --see verb phrases--        
iobj, --see verb phrases--
head, --see verb phrases--        
adjs, --see adjuncts--        
mod,  used as in NPs, for an adjective in a copula, e.g., 'is wealthy'

 [N.B. sentences have the same semantic features as predicates but predicates may have some features missing initially]

 of verb phrases,

pred,     is the SUO name of the action in the verb phrase
subj,     is the subject, agent, or experiencer (first object) of the verb
dobj,     is the direct object (second object) of the verb, or 'empty' if there is none.
iobj,     is the indirect object (second object) of the verb, or 'empty' if there is none.
id,       is the WordNet Synset ID for the action in the verb phrase
head,     is the var name created for the event referred to in the verb phrase (e.g., '?event'), or 'state' if a state is described.
N.B. except for the last two each of these arguments has as its value a set of feature values that describes a complement.

 of noun phrase complements,

noun,       is the actual noun that is accepted as the main noun in the noun phrase (e.g., 'man')
head,       is the variable name created for the primary object referred to in this complement (e.g., '?Man')
type,       is the Sigma concept name for the type of thing which the head is (e.g., 'Man')
id,         is the WordNet Synset ID for the noun that was used to determine the Sigma concept name for the type
mod,        is the Sigma name for a modifier (adjective) that applies to the head
sub,        is the sentence semantics of a relative sentence that modifies the head ('sub' for subordinate sentence).
quan,       is either 'universal', 'existential', or 'definite' depending on the determiner that modifies the head
apos,       is a common noun used in aposition to the proper noun that is the head of this NP.
tag,        only present if this NP is a copy that refers back to an earlier copy created in DRS reduction
% Next features are just for possessive constructs and of constructs, like "X's Y" or "Y of X"
phead,      is the Sigma Concept name for the type of object in the possessive position for the head (e.g., 'John' in 'John's dog')
ohead,      is the Sigma Concept name for the type of object in the of-preposition positions of the head (e.g., 'John' in 'dog of John')
pid,        is the WordNet Synset ID for the object that is in the possessive (owner) position for the head (e.g., 'John' in 'John's dog')
of_id,      is the WordNet Synset ID for the object that is in the of-preposition positions of the head (e.g., 'John' in 'dog of John')
otype,      is the Sigma concept name for the type of thing which the owner in an 'of' expression is (e.g., in 'the card of Bill', Bill)
ptype,      is the Sigma concept name for the type of thing which the owner in a possessive expression is (e.g., 'Bill' in 'Bill's card')

 of adjuncts,

adjs,       is a (possibly empty) list of adjuncts (either adverbs or adverbial prepositional phrases)

 for each adjunct,

adv,        is the Sigma concept name for the adverb in the adjunct, if there is one, or empty, if not
prep,       is the adverbial preposition if there is no adverb
aobj,       is the noun phrase part of the adverbial preposition, aobj stands for adverbial object

Convention: an unknown feature value is the same name as the feature,
only in all caps. E.g., CASE is the unknown value of the 'case'
feature in act<->be..case<->CASE. Also, when the features of a
category are unknown, or represented by a variable, they are
represented by the category name in title case, e.g., 'Sentence' for
the features of a sentence,and 'Relative_Sentence' for a
relative_sentence, etc. If the category is a common abbreviation, like
np, then all caps can be used, so 'NP' would be used for the features
of an np.

*/

%-------------------------------
% NOTE: ALL nouns and determiners
% are singular as per the ACE spec.
%-------------------------------

% pronouns
np(NP) -->
	{ NP = syn<->(det<->empty..case<->CASE..gender<->GENDER..ncat<->NCAT..gcat<->empty..num<->NUMBER..reply<->[Pronoun]) ..
	       sem<->(noun<->NOUN..head<->HEAD..type<->SUO_concept..quan<->definite),
	  Pronoun = syn<->(case<->CASE..gender<->GENDER..num<->NUMBER) ..
	            sem<->(noun<->NOUN..head<->HEAD..type<->SUO_concept) },
	pronoun(Pronoun).             % he...she...him...her...it...

% proper nouns
np(NP) -->
	{ NP = syn<->(case<->CASE..gender<->GENDER..ncat<->NCAT..gcat<->empty..rel<->INSIDE_RELATIVE..num<->NUMBER..reply<->[NOUN]) ..
	       sem<->(noun<->NOUN..head<->HEAD..type<->SUO_concept..id<->Synset_ID..
                      phead<->OWNER..pid<->OWNER_ID..ptype<->PTYPE..
                      ohead<->OF..of_id<->OF_ID..otype<->OTYPE..
		      sub<->Relative_Sentence),
	  NP = Determiner_Features,   % this effectively adds the features found for the determiner to the overall NP feature structure
	  Noun = syn<->(ncat<->NCAT..num<->NUMBER) ..
	         sem<->(noun<->NOUN..head<->HEAD..type<->SUO_concept..id<->Synset_ID..
		       phead<->OWNER..pid<->OWNER_ID..ptype<->PTYPE..
		       ohead<->OF..of_id<->OF_ID..otype<->OTYPE)
	  },	  
	(determiner(Determiner_Features); % we allow determiners here, e.g., 'he arrives in the United States'
	    ( {Determiner_Features = syn<->(det<->empty)..sem<->(quan<->definite) }, empty) ),           
	(proper_noun(Noun) ; possessive1(Noun)),                 % add in parameters for owner and ownee if present
	(of_prep_phrase(OF_PHRASE), { Noun = OF_PHRASE }; empty),% add in parameters for owner in of-prep phrase if present
	(
	  ( { Relative_Sentence = syn<->(gcat<->NCAT..gap<->GAP..rel<->INSIDE_RELATIVE)..sem<->(SUBORDINATE_SEMANTICS) },
	    relative_sentence(Relative_Sentence));
	  % ...or else...
	  ( { Relative_Sentence = 'empty'}, empty)
	).

% common nouns
np(NP) -->
	{ NP = syn<->(det<->DET..case<->CASE..gender<->GENDER..ncat<->NCAT..num<->NUMBER..
		     gcat<->empty..rel<->INSIDE_RELATIVE..reply<->REPLY) ..
	       sem<->(noun<->NOUN..head<->HEAD..type<->SUO_concept..mod<->MODIFIER..id<->Synset_ID..
		       phead<->OWNER..pid<->OWNER_ID..ptype<->PTYPE..
		       ohead<->OF..of_id<->OF_ID..otype<->OTYPE..
		       sub<->Relative_Sentence),
	  NP = Determiner_Features,   % this effectively adds the features found for the determiner to the overall NP feature structure
	  Noun = syn<->(ncat<->NCAT..count<->COUNT..num<->NUMBER) ..
	         sem<->(noun<->NOUN..head<->HEAD..type<->SUO_concept..id<->Synset_ID..
		       phead<->OWNER..pid<->OWNER_ID..ptype<->PTYPE..
		       ohead<->OF..of_id<->OF_ID..otype<->OTYPE)
	  },	  
	(determiner(Determiner_Features); % we allow the determiner to be omitted, but ONLY for mass nouns: 'he gave money to the thief'
	    ( {COUNT = mass, Determiner_Features = syn<->(det<->empty)..sem<->(quan<->indefinite) }, empty) ),           
	allow_modifier(MODIFIER,MODIFIER_REPLY),                     % allow one optional adjective, but do not require it
	(common_noun(Noun); apposition(Noun); possessive2(Noun)),
	(of_prep_phrase(OF_PHRASE), { Noun = OF_PHRASE }; empty),    % add in parameters for owner in of-prep phrase if present

	(
	  ( {  Relative_Sentence = syn<->(gcat<->NCAT..gap<->GAP..rel<->INSIDE_RELATIVE)..sem<->(SUBORDINATE_SEMANTICS) },
	      relative_sentence(Relative_Sentence));
	  % ...or else...
	  ({ Relative_Sentence = 'empty'}, empty)
	),

        % for queries construct the reply from all the parts parsed above, except currently we do not use of-phrases or subordinates.
	{ construct_reply(DET,MODIFIER_REPLY,NOUN,REPLY) }.

% allow_modifier(-MODIFIER,-MODIFIER_REPLY)
% allows but does not require a modifier to be parsed. If one is parsed
% then MODIFIER is set to the SUMO concept for the modifier and the actual
% modifer, the word itself, is returned as MODIFIER_REPLY, which can be
% used in queries in constructing the query reply.

allow_modifier(MOD,MODIFIER_REPLY) -->
	modifier(Modifier),
	{ Modifier = sem<->(mod<->MOD)..syn<->(reply<->MODIFIER_REPLY) }.

allow_modifier(empty,[]) --> empty.

% special case: the 'gap' grammatical feature can be used to replace a missing NP in a relative sentence
% E.g., ...N.B. parses *nothing* but uses up the gap feature, can only happen if gap feature is not empty...
% Note: the rel feature must be 'yes' since a gap can only be used up inside relative sentences as this version
% does not yet handle queries.
np(NP) -->
	{ NP = syn<->(det<->empty..case<->CASE..gender<->GENDER..ncat<->GCAT..gcat<->GCAT..gap<->GAP..rel<->yes..reply<->[Sigma_Name]) ..
	       sem<->(head<->Sigma_Name..type<->SUO_concept..quan<->definite),
	       not(var(GCAT)), not(GCAT=empty),
	       create_var_name(GAP,Sigma_Name),
               map_gcat_to_suo(GCAT,SUO_concept) },
	empty.                                               % Nothing is parsed! Instead, use the gap construct to fill in the NP.

% (optional) adjective modifiers (only one allowed, ACE does not allow these to be strung together)
% E.g., ...valid...Swiss...new...fastest...most expensive...
% Note: MODIFIER is the SUO name of the modifier.
modifier(MODIFIER) -->
	adjective(MODIFIER); superlative(MODIFIER).

% possessives

% Proper noun, not requiring a determiner preceding it.
% E.g., ...John's card...Mary's bank...
possessive1(Noun) -->
	proper_noun(Owner),
	apostrophe_s,
	common_noun(Possession),
	{ 
          Owner = sem<->(head<->OWNER_HEAD..type<->OWNER_TYPE..id<->OWNER_ID),
	  Possession = syn<->(ncat<->NCAT..num<->NUMBER) .. sem<->(noun<->OBJECT..head<->POSS_HEAD..type<->POSS_TYPE..id<->POSS_ID),
	  Noun = syn<->(ncat<->NCAT..num<->NUMBER) ..                                            % type of thing owned (object, person,...)
	         sem<->(noun<->OBJECT..head<->POSS_HEAD..type<->POSS_TYPE..id<->POSS_ID..        % first describe what is owned
		       phead<->OWNER_HEAD..pid<->OWNER_ID..ptype<->OWNER_TYPE..quan<->definite)  % then add descriptions of the owner
	}.
	
% Common noun, requiring a determiner preceding it.
% E.g., ...bank's card...customer's bank...machine's slot...
% Note we don't handle banks' card, customers' card, machines' slot,
% but do handle bank's cards, customer's banks, machine's slots, and so on.
possessive2(Noun) -->
	common_noun(Owner),
	apostrophe_s,
	common_noun(Possession),
	{ 
          Owner = sem<->(head<->OWNER_HEAD..type<->OWNER_TYPE..id<->OWNER_ID),
	  Possession = syn<->(ncat<->NCAT..num<->NUMBER) .. sem<->(noun<->OBJECT..head<->POSS_HEAD..type<->POSS_TYPE..id<->POSS_ID),
	  Noun = syn<->(ncat<->NCAT..num<->NUMBER) ..                                            % type of thing owned (object, person,...)
                 sem<->(noun<->OBJECT..head<->POSS_HEAD..type<->POSS_TYPE..id<->POSS_ID..        % first describe what is owned
		       phead<->OWNER_HEAD..pid<->OWNER_ID..ptype<->OWNER_TYPE..quan<->definite)  % then add descriptions of the owner
	}.

% X's Y
% The owned object (Y) is treated as the head of the noun phrase.
%                      X | Y
%                  ------------
% SUMO type         ptype| type
% Sigma variable    phead| head
% WordNet ID        pid  | id

% Y of X
% The owned object (Y) is treated as the head of the noun phrase.
%                      X | Y
%                  ------------
% SUMO type         otype| type
% Sigma variable    ohead| head
% WordNet ID        of_id| id

% prepositional phrase used to modify a noun, ACE requires that it begins with 'of'

% E.g., ...of Mary...of John...
of_prep_phrase(OF_PHRASE) -->
	[of],
	(empty;determiner(DET)),  /* allow an optional determiner, e.g., ...of the United States... */
	proper_noun(NOUN),
	{
	 NOUN = sem<->(head<->POSS_HEAD..type<->POSS_TYPE..id<->POSS_ID),
	 OF_PHRASE = syn<->ANY..sem<->(ohead<->POSS_HEAD..of_id<->POSS_ID..otype<->POSS_TYPE..quan<->definite)
	}.

% E.g., ...of the bank...of the customer...
of_prep_phrase(OF_PHRASE) -->
	[of],
	determiner(DET),
	common_noun(NOUN),
	{
	 NOUN = sem<->(head<->POSS_HEAD..type<->POSS_TYPE..id<->POSS_ID),
	 OF_PHRASE = syn<->ANY..sem<->(ohead<->POSS_HEAD..of_id<->POSS_ID..otype<->POSS_TYPE..quan<->definite)
	}.	

% E.g., ...of money...of butter...
of_prep_phrase(OF_PHRASE) -->
	[of],
	common_noun(NOUN),
	{
	 NOUN = syn<->(ncat<->NCAT..count<->mass) ..
	        sem<->(head<->POSS_HEAD..type<->POSS_TYPE..id<->POSS_ID),
	 OF_PHRASE = syn<->ANY..sem<->(ohead<->POSS_HEAD..of_id<->POSS_ID..otype<->POSS_TYPE..quan<->definite)
	}.	

% apostrophe followed by s
% E.g., ...'s...
apostrophe_s --> ['\'',s].                 

% Problem special cases to rule out rapidly. We also have a more general filter for anomalous
% appositions in ruled_out_anomalous_appositions/1, see below. But toss these two particular
% ones aside quickly as they come up a lot.

apposition(Noun) --> [does],{!,fail}.
apposition(Noun) --> [at],{!,fail}.

% (optional) appositions, here we handle constructions with dynamic labels like 'bank Y'
% The noun specifier's type and number are copied to the apposition's type and number.
apposition(Noun) --> common_noun(Specifier_Noun), new_label(Noun),
	{ Specifier_Noun = syn<->(ncat<->NCAT..num<->NUMBER)..sem<->(noun<->Apposition_Noun..type<->SUO_concept),
	  Noun = syn<->(ncat<->NCAT..num<->NUMBER)..sem<->(type<->SUO_concept),
	  ruled_out_anomalous_appositions(Apposition_Noun)
	}.

% (optional) appositions, here we handle constructions with proper nouns like 'customer Mr Miller'
% The noun specifier's type and number are copied to the apposition's type and number.
apposition(Noun) --> common_noun(Specifier_Noun), proper_noun(Proper_Noun),
	{ Specifier_Noun = syn<->(num<->NUMBER)..sem<->(noun<->Apposition_Noun..type<->Explicit_type),
	  Proper_Noun = syn<->(ncat<->NCAT) ..
                        sem<->(head<->Name..type<->Implicit_type),   
	  Noun = syn<->(ncat<->NCAT..num<->NUMBER) ..
	         sem<->(head<->Name..type<->Explicit_type),
	  ruled_out_anomalous_appositions(Apposition_Noun)
	  }.

% ruled_out_anomalous_appositions(+Apposition_Noun)
% succeeds if Apposition_Noun (e.g., 'customer') cannot be interpreted as a common verb
% preposition or other function word. See the pathological examples below to see why we want
% to rule these out.

% Prevent queries such as 'What does John read?' from being parsed as anomalous appositions
% where 'does' is interpreted as female deer. Also prevent sentences such as
% 'John gives Mary a banana. She throws it at John.' from being interpreted in anomalous ways
% such as where 'at' is interpreted as a Laotian unit of currency! so that 'at him' is an
% apposition. Instead, require that the noun be only a noun and not a preposition (like 'at')
% or verb (like 'does').

% Rule out predefined words like 'no' which is a negative.
ruled_out_anomalous_appositions(Apposition_Noun) :-
	predefined_word(Apposition_Noun),
	!,
	fail.

% Rule out determiners like 'a' which can also be a blood group!
ruled_out_anomalous_appositions(Apposition_Noun) :-
	determiner_in_lexicon(Apposition_Noun,DefiniteOrNot,UniversalOrNot),
	!,
	fail.

% Rule out prepositions like 'at' which can also be a unit of Laotian money currency!
ruled_out_anomalous_appositions(Apposition_Noun) :-
	preposition_in_lexicon(Apposition_Noun,Modification_type,Noun_type,SUO_concept),
	!,
	fail.

% Rule out verbs like 'does' which can appear to be plural nouns!
ruled_out_anomalous_appositions(Apposition_Noun) :-
	verb_in_lexicon(Apposition_Noun,Root,TransitivityList,Number,Kind_of_verb,Event_or_state,SUO_concept,Synset_ID),
	!,
	fail.

% And if we run the gauntlet to this point everything appears OK!
ruled_out_anomalous_appositions(Apposition_Noun) :- true,!.

% new labels
% E.g., ...X...Y...Z...[N.B. none others at present]...
new_label(Noun) --> unknown_proper_noun(Noun).               % currently restricted to 'X', 'Y', or 'Z' to facilitate generation

% relative sentences, these must follow an NP, note these require the 'gap' grammatical feature
% E.g., ...who checks it...who gives the card to the employee...that the customer inserts...
% Note: the rel features is 'no' for the relative sentence since it cannot itself be embedded
% within another surrounding relative sentence. On the other hand the rel feature is 'yes' for
% the embedded sentence since that sentence is indeed within a relative sentence.
relative_sentence(Relative_Sentence) -->        
	{ Relative_Sentence = syn<->(gcat<->GCAT..gap<->GAP..rel<->no..act<->ACT..vcat<->VCAT) ..
	                      sem<->EMBEDDED_SENTENCE_SEMANTICS,
	  Relative_Pronoun  = syn<->(ncat<->GCAT..gap<->GAP),
	  Embedded_Sentence = syn<->(gcat<->GCAT..gap<->GAP..act<->ACT..vcat<->VCAT..rel<->yes..max<->3) ..
	                      sem<->EMBEDDED_SENTENCE_SEMANTICS },
	relative_pronoun(Relative_Pronoun),
	embedded_sentence(Embedded_Sentence).
        
% Note that 'that' referring to an entire sentence is not handled, for example,
% 'He sees that she is reading.' or 'He knows what she says.'

% optional element
% E.g., ...parses nothing!...
empty --> [].

%-------------------------------
% PARTS OF SPEECH TO LEXICON
%-------------------------------

determiner(Determiner_Features)  -->
	[Determiner],
	{ determiner_in_lexicon(Determiner,Definite_Or_Not,Universal_Or_Not),
	  Determiner_Features = syn<->(det<->Determiner)..sem<->(quan<->Universal_Or_Not) }.

% handle either single word or compound word nouns

common_noun(Noun) --> 
                [Word],				% single word noun, singular number, such as 'boy'
               {
		 % Syntactic grammatical features...
		 Noun = syn<->(ncat<->NCAT..count<->Countability..num<->singular) ..
	                sem<->(noun<->Word..head<->Sigma_Name..type<->SUO_concept..id<->Synset_ID),
% JL: use co-occurrence matching. Since NCAT is pre-assigned, it needs to be matched before anything else	  
	  	 ((noun_in_lexicon(Word,NCAT,_,_,_,_,_),
	  	   find_synset(Word, n, Synset_ID))
	  	   ; true),	% it can be bypassed if there is no record satisfying both NCAT and the Synset_ID chosen by 
	   			% find_synset
	
	  	 noun_in_lexicon(Word,NCAT,Gender,Countability,Number,SUO_concept,Synset_ID),
		 atom(Word),
		 % Semantic grammatical features...
		 create_var_name(Word,Sigma_Name)
	       }.


common_noun(Noun) --> 
                [Word],				% single word noun, plural number, such as 'boys'
               {
		 % Syntactic grammatical features...
		 Noun = syn<->(ncat<->NCAT..count<->Countability..num<->plural) ..
	                sem<->(noun<->Singular_Noun..head<->Sigma_Name..type<->SUO_concept..id<->Synset_ID),
		 plural_noun_to_singular(Word,Singular_Noun),
% JL: use co-occurrence matching. Since NCAT is pre-assigned, it needs to be matched before anything else	  
		 ((noun_in_lexicon(Singular_Noun,NCAT,_,_,_,_,_),
	  	   find_synset(Singular_Noun, n, Synset_ID))
	  	   ; true),	% it can be bypassed if there is no record satisfying both NCAT and the Synset_ID chosen by 
	   			% find_synset
	
		 noun_in_lexicon(Singular_Noun,NCAT,Gender,Countability,Number,SUO_concept,Synset_ID),
		 atom(Word),
		 % Semantic grammatical features...
		 create_var_name(Word,Sigma_Name)
	       }.

common_noun(Noun) -->
	       [First],                        % compound word noun, singular number, such as 'breach of trust'
	       { Noun = syn<->(ncat<->NCAT..count<->Countability..num<->singular) ..
	                sem<->(noun<->[First,Second|Rest]..head<->Sigma_Name..type<->SUO_concept..id<->Synset_ID),
% JL: use co-occurrence matching. Since NCAT is pre-assigned, it needs to be matched before anything else	  
		 ((noun_in_lexicon([First,Second|Rest],NCAT,_,_,_,_,_),
	  	   find_synset([First,Second|Rest], n, Synset_ID))
	  	   ; true),	% it can be bypassed if there is no record satisfying both NCAT and the Synset_ID chosen by 
	   			% find_synset
	
		 noun_in_lexicon([First,Second|Rest],NCAT,Gender,Countability,Number,SUO_concept,Synset_ID),
		 % Semantic grammatical features...
		 create_var_name([First,Second|Rest],Sigma_Name)
		 },
               [Second|Rest].     % compound word common noun



common_noun(Noun) -->
	       [First],                        % compound word noun, plural number, such as 'breaches of trust'
	       { Noun = syn<->(ncat<->NCAT..count<->Countability..num<->plural) ..
	                sem<->(noun<->[Singular_First_Word,Second|Rest]..head<->Sigma_Name..type<->SUO_concept..id<->Synset_ID),
		 plural_noun_to_singular(First,Singular_First_Word), % e.g., 'breaches' to 'breach' in the example above
% JL: use co-occurrence matching. Since NCAT is pre-assigned, it needs to be matched before anything else	  
		 ((noun_in_lexicon([Singular_First_Word,Second|Rest],NCAT,_,_,_,_,_),
	  	   find_synset([Singular_First_Word,Second|Rest], n, Synset_ID))
	  	   ; true),	% it can be bypassed if there is no record satisfying both NCAT and the Synset_ID chosen by 
	   			% find_synset
	
		 noun_in_lexicon([Singular_First_Word,Second|Rest],NCAT,Gender,Countability,Number,SUO_concept,Synset_ID),
		 % Semantic grammatical features...
		 create_var_name([First,Second|Rest],Sigma_Name)
		},
               [Second|Rest].     % compound word common noun	       

% handle either single word or compound proper nouns
proper_noun(Proper_Noun) --> 
		      [Name],       % single word proper noun
	              { Proper_Noun = syn<->(ncat<->NCAT..num<->singular) ..
		                      sem<->(noun<->Name..head<->HEAD..type<->Sigma_type..id<->Synset_ID),
			atom(Name),
/*
% Proper noun has less ambiguity so this is unnecessary.  In addition, this can be expensive since there is heavy 
% cost to solve the case matching problem with s/6.
% JL: use co-occurrence matching	  
	  	 	find_synset(Name, n, Synset_ID),
*/	
			proper_noun_in_lexicon(Name,NCAT,Gender,Number,Sigma_type,SUO_constant,Synset_ID),
                        % If the proper noun is the name of an ethnic subgroup, like 'German', then use var like '?German', 
		        % otherwise, for most cases, just use the constant the proper name mapped to, like 'John-1'.
			(is_an_ethnic_group(Sigma_type) -> create_var_name(Name,HEAD); HEAD = SUO_constant)
		      }.

% handle newly introduced proper nouns, if there are any to consider.
proper_noun(Proper_Noun) --> 
		      [Name],       % single word proper noun
                      { new_proper_names(Added_Proper_Names), Added_Proper_Names \== [], memberchk(Name,Added_Proper_Names),
	                Proper_Noun = syn<->(ncat<->person..num<->singular)..
		                      sem<->(noun<->Name..head<->'Person-1'..type<->'Human'..id<->empty)
		      }.

%   asserta(proper_noun_in_lexicon(Word,person,masculine,singular,['Human','Male','FullyFormed'],'Person-1',empty)).
%   retractall(proper_noun_in_lexicon(Word,person,masculine,singular,['Human','Male','FullyFormed'],'Person-1',empty)).

proper_noun(Proper_Noun) -->
	            [First],
	            { Proper_Noun = syn<->(ncat<->NCAT..num<->singular) ..
		                    sem<->(noun<->[First,Second|Rest]..head<->HEAD..type<->Sigma_type..id<->Synset_ID),
/*
% Proper noun has less ambiguity so this is unnecessary.  In addition, this can be expensive since there is heavy 
% cost to solve the case matching problem with s/6.
% JL: use co-occurrence matching	  
	  	      find_synset([First,Second|Rest], n, Synset_ID),
*/	

		      proper_noun_in_lexicon([First,Second|Rest],NCAT,Gender,Number,Sigma_type,SUO_constant,Synset_ID),
                      % If the proper noun is the name of an ethnic subgroup, like 'German', then use var like '?German', 
		      % otherwise, for most cases, just use the constant the proper name mapped to, like 'John-1'.
		      (is_an_ethnic_group(Sigma_type) ->
			  create_var_name([First,Second|Rest],HEAD); HEAD = SUO_constant)
		    },
		    [Second|Rest]. % compound word proper noun


% Note that the type feature and the noun category feature (ncat) are set by the noun specifier, not here.
unknown_proper_noun(Proper_Noun) -->
	      [Name],
	      { member(Name,['X','Y','Z']),
		make_KIF_var(Name,KIF_VAR),
		Proper_Noun = syn<->(ncat<->_)..sem<->(head<->KIF_VAR..type<->_) }.

pronoun(Pronoun) -->
	{ Pronoun = syn<->(case<->CASE..gender<->GENDER..num<->Number) ..
	            sem<->(noun<->Word..head<->Sigma_Name..type<->Sigma_type..quan<->definite), % and it is a definite reference
	  pronoun_in_lexicon(Word,CASE,GENDER,Number,Sigma_type),
   	  % Semantic grammatical features...
          create_var_name(Word,Sigma_Name)
	  },
        [Word].

relative_pronoun(Relative_Pronoun) -->
	{ Relative_Pronoun = syn<->(ncat<->NCAT..gap<->Word)..  % NCAT is one of [person, time, object]
	                     sem<->(quan<->definite),           % and it is a definite reference
	  relative_pronoun_in_lexicon(Word,NCAT) },
	[Word].

% Handle either single word (e.g., red) or compound word (e.g., first class) common adjectives
% Note: MOD is the SUO name of the modifier.
adjective(MODIFIER) --> 
	      { adjective_in_lexicon(Word,Root,normal,positive,MOD),
		atom(Word),
		MODIFIER = sem<->(mod<->MOD)..syn<->(reply<->Word)},		% single word adjective
              [Word].				

adjective(MODIFIER) -->
	{ adjective_in_lexicon([First|Rest],Root,normal,positive,MOD),
	  MODIFIER = sem<->(mod<->MOD)..syn<->(reply<->[First|Rest])
	},
	      [First|Rest].                     % compound word adjective
                                                % [Note: two-place, comparative, & superlative adjectives are in Sentence DCG rules.]


% Handle numeric modifiers here. These expressions at present allow only integers optionally
% followed by units of measurements, e.g., '124', '123 meters', etc.

% Currently, signs, decimals, fractions, different bases, and floating point notation are not handled.

numeric_modifier(MODIFIER) -->  % try the longer expression first, with units of measure.
	[Word],				
	{ atom(Word),
	  atom_representing_number(Word),
	  convert_atom_to_number(Word,Number)
	},	% single word for an integer followed by units of measure.
	common_noun(Measure),
	{
	  Measure = sem<->(noun<->NOUN..head<->HEAD..type<->SUO_concept..id<->Synset_ID),
	  MODIFIER = sem<->(mod<->[Number,SUO_concept])..syn<->(reply<->[Word,HEAD])
	}.

numeric_modifier(MODIFIER) --> % next try the shorter expression, without units of measure.
	[Word],
	{ atom(Word),
	  atom_representing_number(Word),
	  convert_atom_to_number(Word,Number),
	  MODIFIER = sem<->(mod<->Number)..syn<->(reply<->Word)
	}.	% single word for an integer with no units of measure.


	 