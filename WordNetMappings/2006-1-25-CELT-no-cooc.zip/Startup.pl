% System definition and startup file for CELT.
% CELT Version 3(b)--Simple sentences, WH queries, and Yes/No queries.
% Also limited discourse and quantifier capabilities.

% William R. Murray
% Copyright � 2002, 2003 Teknowledge Corporation
% This software released under the GNU Public License <http://www.gnu.org/copyleft/gpl.html>.

:-module(celt,
 	 [

          % Here are the top-level calling functions to invoke CELT from within SWI-Prolog
	  top_level/0,                             % Call CELT top level, accept sentence or query input, accept commands.
	  eng2log/1,                               % Translate from English to logic. Print output.
	  xml_eng2log/2,                           % As above, but provide output as a string variable with XML tags.
	  single_sentence_eng2log/1,               % Original version of eng2log/1, for single sentences or queries only.
	  print_celt_version/0,                    % Print the current version of CELT.
          xml_single_sentence_eng2log/2,           % As above, but provides output as a string variable with XML tags.
          write_all_noun_defs/1,                   % Lists all word senses loaded currently for a particular noun.
          write_all_proper_noun_defs/1,            % Lists all word senses loaded currently for a particular proper noun.
          write_all_verb_defs/1,                   % Lists all word senses loaded currently for a particular verb.
          translate/2,                             % Requests CELT translation of a grammar nonterminal (e.g., np) with a string.
	  test_CELT/0,                             % Runs the approximately 185 stored CELT tests and scores them.

	  define_new_noun_for_lexicon/0,           % Adds a new noun to CELT's currently loaded lexicon.
	  define_new_verb_for_lexicon/0,	   % Adds a new verb to CELT's currently loaded lexicon.
	  define_new_adjective_for_lexicon/0,	   % Adds a new adjective to CELT's currently loaded lexicon.
	  define_new_adverb_for_lexicon/0,	   % Adds a new adverb to CELT's currently loaded lexicon.	  	  
	  define_new_abbreviation/0,               % Add a new abbreviation to CELT's currently loaded lexicon.
	  save_new_lexicon/0,                      % Save newly defined lexical terms added by forms above in this session.
	  load_new_lexicon/0,                      % Reload recently defined lexical terms defined and saved in a prior session.

          % Alternatively, to call from another application over TCP-IP sockets, these functions may be used.
	  create_server/1,                         % Create a CELT server that takes commands and returns replies over the port specified.
	  celt/3,                                  % Used to call xml_eng2log/2 in server.pl.
	  celt/5,                                  % Used to call add_abbreviation_template/2 in add_words.pl.	  
	  celt/6,                                  % Used to call add_adverb_template/3 in add_words.pl.
	  celt/8,                                  % Used to call add_adjective_template/5 in add_words.pl.
	  celt/9,                                  % Used to call add_noun_template/7 in add_words.pl.
	  celt/10,                                 % Used to call add_verb_template/8 in add_words.pl.	  

          % These next functions set flags and parameters for CELT
	  reset_flags_to_defaults/0,               % reset all CELT flags to their default values.
	  no_atp_interface/0,                      % no interface to any prover, i.e., translate, but do not assert/query.
	  use_atp_interface/0,                     % turn on interface to any prover, i.e., translate, and then assert or query
	  use_file_atp_interface/0,                % use the file I/O to communicate to an ATP like OTTER or SNARK
	  use_embedded_atp_interface/0,            % use Prolog function calls to call a Prolog-embedded theorem prover or query evaluator
	  enable_embedded_prover/0,                % enable query and assert to embedded knowledge base thru Prolog query evaluator
	  disable_embedded_prover/0,               % disable query and assert to embedded knowledge base thru Prolog query evaluator
	  toggle_embedded_prover/0,                % enable/disable query and assert to embedded knowledge base thru Prolog query evaluator
	  disable_all_interfaces/0,                % turn off all ATP interfaces (only one at most should be on anyway)
	  drt_messages_on/0,                       % print out trace messages detailed construction and analysis of DRSes
	  drt_messages_off/0,                      % no longer print out trace messages detailed construction and analysis of DRSes
	  do_assume_pronouns_human/0,              % assume 'he', 'her', 'him', and 'her' refer to humans
	  do_not_assume_pronouns_human/0,	   % do not assume 'he', 'her', 'him', and 'her' refer to humans
          add_type_info_in_generated_KIF/0,        % add type info in generated KIF
	  suppress_type_info_in_generated_KIF/0,   % suppress type info in generated KIF
	  save_debug_forms_on/0,                   % save special forms used to assist in debugging and development work.
	  save_debug_forms_off/0,                  % do not save special forms used to assist in debugging & development work.

	  % These next functions are useful for debugging and development in CELT
	  list_saved_answers/0,                    % list answers saved by embedded Prolog reasoner to queries that were asked
	  lookup_word_in_lexicon/1,                 % find all entries in CELT lexicon matching the word given
          find_synset/3,
          cooc/5
	 ]
	).

% CELT's lexical vocabulary is dynamic at runtime, but not its ontology. It's ontology can
% change between load sessions, but not at runtime. So the following predicates, referring
% lexical entries are dynamic, whereas those referring to ontology entries, need not be.

:- dynamic noun_in_lexicon/7.
:- dynamic verb_in_lexicon/8.
:- dynamic proper_noun_in_lexicon/7.
:- dynamic stative_verb/5.
:- dynamic adjective_in_lexicon/5.
:- dynamic adverb_in_lexicon/3.
:- dynamic translation_template/4.
:- dynamic abbreviation/2.

% declarations needed for embedded reasoner until
% we put it in its own module.
:- dynamic possesses/2.
:- multifile possesses/2.

fact(0,1).

fact(N,N_FACTORIAL) :-
 	N > 0, 
 	N_SUB_1 is N - 1,
 	fact(N_SUB_1,N_SUB_1_FACTORIAL),
 	N_FACTORIAL is N * N_SUB_1_FACTORIAL.

% N.B. The reason that 'make' and 'help' and 'guitracer' are called
% here, when there appears no reason to do so, is so they will be
% autoloaded now, before the GULP feature grammar rules are loaded
% which redefine the syntax of various operators and the operation
% of file loading, which interferes with loading these files later.--WRM.

load_help_facilities :- make,help(atom),guitracer. % To test the GUI tracer call trace. and then, fact(4,N). after loading.

:- load_help_facilities,consult(grapher).

% DECLARATIONS

:-multifile noun_in_lexicon/7.
:-multifile verb_in_lexicon/8.
:-multifile proper_noun_in_lexicon/7.
:-multifile stative_verb/5.
:-multifile adjective_in_lexicon/5.
:-multifile adverb_in_lexicon/3.
:-multifile translation_template/4.
:-multifile abbreviation/2.

:-multifile test/3.
:-multifile copula/3.
:-multifile verb/3.
:-multifile np/3.
:-multifile embedded_sentence/3.
:-multifile relation/4.
:-multifile drs/6.
:-multifile reset_all_generated_names/0.

% terms that appear in KIF ontology files converted to Prolog:

:-dynamic meetsSpatially/2.
:-dynamic geographicSubregion/2.
:-dynamic orientation/3.
:-dynamic totalArea/2.
:-dynamic objectGeographicCoordinates/3.
:-dynamic has_length/2.
:-dynamic comparativeArea/4.
:-dynamic naturalHazardTypeInArea/2.
:-dynamic elevation/2.
:-dynamic located/2.
:-dynamic totalArea/2.
:-dynamic orientation/3.
:-dynamic geographicSubregion/2.
:-dynamic economyType/2.
:-dynamic agentOperatesInArea/2.
:-dynamic subOrganization/2.
:-dynamic is_member/2.
:-dynamic holdsDuring/2.
:-dynamic dateEstablished/2.
:-dynamic localShortName/2.
:-dynamic localLongName/2.
:-dynamic names/2.
:-dynamic part/2.
:-dynamic exists/2.
:-dynamic abbreviation/2.
:-dynamic conventionalLongName/2.
:-dynamic conventionalShortName/2.
:-dynamic contraryAttribute/2.
:-dynamic documentation/1.
:-dynamic formerName/2.
:-dynamic synonymousExternalConcept/3.
:-dynamic is_not/1.
:-dynamic for_all/2.
:-dynamic disjointDecomposition/5.
:-dynamic equal/2.
:-dynamic subclass/2.
:-dynamic documentation/2.
:-dynamic instance/2.
:-dynamic '=>'/2.
:-dynamic '<=>'/2.
:-dynamic subrelation/2.
:-dynamic domain/2.
:-dynamic domain/3.
:-dynamic range/2.
:-dynamic rangeSubclass/2.
:-dynamic disjoint/2.
:-dynamic domainSubclass/3.
:-dynamic 'relatedInternalConcept'/2.
:-dynamic subAttribute/2.
:-dynamic attribute/2.
:-dynamic successorAttribute/2.

% terms that appear in KIF ontology files converted to Prolog:

:-multifile meetsSpatially/2.
:-multifile geographicSubregion/2.
:-multifile orientation/3.
:-multifile totalArea/2.
:-multifile objectGeographicCoordinates/3.
:-multifile has_length/2.
:-multifile comparativeArea/4.
:-multifile naturalHazardTypeInArea/2.
:-multifile elevation/2.
:-multifile located/2.
:-multifile totalArea/2.
:-multifile orientation/3.
:-multifile geographicSubregion/2.
:-multifile economyType/2.
:-multifile agentOperatesInArea/2.
:-multifile subOrganization/2.
:-multifile is_member/2.
:-multifile holdsDuring/2.
:-multifile dateEstablished/2.
:-multifile localShortName/2.
:-multifile localLongName/2.
:-multifile names/2.
:-multifile part/2.
:-multifile exists/2.
:-multifile abbreviation/2.
:-multifile conventionalLongName/2.
:-multifile conventionalShortName/2.
:-multifile contraryAttribute/2.
:-multifile documentation/1.
:-multifile formerName/2.
:-multifile synonymousExternalConcept/3.
:-multifile is_not/1.
:-multifile for_all/2.
:-multifile disjointDecomposition/5.
:-multifile equal/2.
:-multifile subclass/2.
:-multifile documentation/2.
:-multifile instance/2.
:-multifile '=>'/2.
:-multifile '<=>'/2.
:-multifile subrelation/2.
:-multifile domain/2.
:-multifile domain/3.
:-multifile range/2.
:-multifile rangeSubclass/2.
:-multifile disjoint/2.
:-multifile domainSubclass/3.
:-multifile 'relatedInternalConcept'/2.
:-multifile subAttribute/2.
:-multifile successorAttribute/2.
:-multifile attribute/2.


% declare syntactic and semantic features used in ACE / CELT rules, see
% end of this file for documentation of each feature.

% FILES

% The basic CELT files must be loaded before any other files are loaded.
basic_celt_files([
		  % Flags used throughout CELT for basic parameter switches
		  flags,
		  % Next file defines tools such as print_herald, string and list processing, etc. used by later files
		  tools,
		  % Next file defines code to read in KIF files and convert them to Prolog clauses that CELT can reason with
		  read_KIF
		 ]).


% The unification grammar rules and feature grammar extension
celt_grammar([
                  % First file is for TEK GULP 3.1, support for unification grammars
   	          swi_gulp_iff_sign, 
		  % Second file is set of grammar features declared,
		  features,
	          % Next files are DCG rules, built-in lexicon, and supporting code
		  np,sentence,query
		 ]).


user_ontology_extensions([
		% Insert user-defined domain-specific ontology extensions here that are to extend the SUMO.
		% Include the most specific files first and the most general last. All should be in the
		% 'User Ontology Extensions' folder with *.txt extensions for KIF files and *.pl extensions
		% for the converted Prolog files. You can call convert_KIF_to_Prolog to manually convert your files
		% or let CELT do the conversion upon loading the system if there is no *.pl file for a *.txt file.
		% *****INSERT YOUR MOST-SPECIFIC SUMO ONTOLOGY EXTENSION FILES RIGHT BELOW HERE*************
		'.\\User Ontology Extensions\\Afghanistan_1_17',
		'.\\User Ontology Extensions\\People_1_1',
		'.\\User Ontology Extensions\\Government_1_15',
		'.\\User Ontology Extensions\\Economy_1_6',
		'.\\User Ontology Extensions\\Geography_1_12',
		'.\\User Ontology Extensions\\AROBEALD_Midlevel_1_7',
		'.\\User Ontology Extensions\\FinancialOntology',
		'.\\User Ontology Extensions\\EthnicGroups',
		'.\\User Ontology Extensions\\AreaOfOperations',
		'.\\User Ontology Extensions\\TQ_Axioms_3_10',
		'.\\User Ontology Extensions\\EthnicGroups',
		'.\\User Ontology Extensions\\ATF_Ontology'
		% **************INSERT YOUR LEAST-SPECIFIC SUMO ONTOLOGY FILES RIGHT ABOVE HERE*************
			  ]).


user_lexicon_extensions([
		% Insert user-defined domain-specific lexicon files here that are to override the built-in lexicon
		% or imported WordNet lexicon. Include the most specific files first and the most general last.
		% All should be in the 'User Lexicons' folder with *.pl extensions.
		% *********************INSERT YOUR MOST-SPECIFIC LEXICON FILES RIGHT BELOW HERE*************
		'.\\User Lexicons\\France_Lexicon',
		'.\\User Lexicons\\Government_Lexicon',
		'.\\User Lexicons\\People_Lexicon',			 
		'.\\User Lexicons\\lex1',              % Example lexicon, just has one word sense for 'box', the most specific sense
		'.\\User Lexicons\\lex2',              % Example lexicon, just has a different word sense for 'box', a more general sense
		'.\\User Lexicons\\lex3',              % Example lexicon, just has yet another word sense for 'box', yet more general
		'.\\User Lexicons\\ATO_Lexicon',       % ATO lexicon (air tasking order)
		'.\\User Lexicons\\ATF_Lexicon'        % ATF lexicon (armored task force)
		% ********************INSERT YOUR LEAST-SPECIFIC LEXICON FILES RIGHT ABOVE HERE*************
	        % N.B. Default senses of 'box' from standard lexicon as well as other nouns, verbs, etc. will follow after these.	 
			 ]).

% Built-in lexicon for CELT along with lexical entries imported from WordNet.
celt_lexicon_files([
		% Core lexicon -- always needs to be present
		lexicon,
		% Next files are lexicon files generated from WordNet using the Perl 
		% program wn2assoc3 and the Prolog create_lexicon program.
		statives,celt_common_noun_lexicon,celt_proper_noun_lexicon,celt_verb_lexicon,celt_adjective_lexicon,celt_adverb_lexicon
		   ]).

% Once the basic CELT files are loaded then the main CELT data files, below, can be loaded.
main_celt_data_files([
		% Latest SUMO...Merge 1.48
		kif,
		% WordNet 1.6 files...
		wn_s,wn_g,wn_hyp,
		% Next are files for catching morphological variants of items in the lexicon
		morphy,verb_excepts,noun_excepts,adj_excepts,adv_excepts]).

% The main CELT process files follow the main CELT data files. These need the CELT grammar extensions.
main_celt_code_files([
		% top-level calling functions
		top_level,
		% Generation of KIF code with translation warnings...
		semantics,warnings,
		% Files for inheritance reasoning over either SUMO or WordNet
		infer_sumo,infer_wordnet,		
		% Files to implement Discourse Representation Structures (DRSs)
		% and Discourse Representation Theory (DRT).
		compounds,canonic_form,discourse,drs_rules,anaphora,drt_code_gen,
		% Files for interfacing with the automatic theorem prover (e.g., SNARK, OTTER, or VAMPIRE)
		atp_interface,
                % Files for adding new words to the lexicon
                add_words,		      
		% client-server code to allow CELT to act as a server for other programs
		server,client,      
		% Next are advanced dialog capabilities files for evaluating free text student answers w.r.t. reference answers
		compare,
		% Code to generate answers to queries
		reply,
		% Last are files for regression testing of parsing, these do not need to be loaded when efficiency is paramount.
		tests,
		'.\\tests\\tests_sentence',
		'.\\tests\\tests_query',
		'.\\tests\\tests_np',
		find_best_sense
		]).

% load_CELT/0
% Load order...
%    basic utilities
%    domain-specific (user-defined) lexicons
%    built-in (general, from WordNet) lexicons
%    SUMO (Merge data file)
%    WordNet data files
%    Morphy data files
%    domain-specific (user-defined) ontology extensions to SUMO
%    GULP feature grammar extensions
%    CELT grammar rules
%    CELT code files
% N.B. that the order in which the lexicons is loaded is
% significant as the user-defined lexical entries may 'shadow',
% be retrieved before the defaults that the default vocabulary
% would provide. This is not the case for the ontology extensions
% as there is no shadowing there. In this case the user extensions
% should follow the general ontology as they build on it, rather
% than supersede it.

load_CELT :-
	basic_celt_files(BASICS),
	format("Loading basic CELT utilities and tools...~n"),
	consult(BASICS),
	load_user_defined_lexicons,
	load_celt_core_lexicon,
	format("Loading CELT WordNet data and SUMO ontology data files...~n"),
	main_celt_data_files(CELT_DATA_FILES),
	consult(CELT_DATA_FILES),
	format("Done loading CELT WordNet data and SUMO ontology data files...~n"),
	format("Loading user-defined ontology extensions to SUMO...~n"),
	% load_user_ontologies,
	format("Done loading user-defined ontology extensions to SUMO...~n"),
	format("Loading CELT grammar extensions and grammar rules...~n"),
	load_celt_grammar,
	format("Done loading CELT grammar extensions and grammar rules...~n"),
	format("Loading CELT lexicon and ontology code files that depend on these grammar extensions and rules...~n"),
	main_celt_code_files(CELT_CODE_FILES),
	consult(CELT_CODE_FILES),	
	format("Done loading CELT lexicon and ontology code files...~n"),
	format("Successfully loaded ALL of CELT!~n"),
	celt_init,
	format("Done initializing.~n").
	
% load unification grammar extension first, then
% load DCG grammar rules that use this extension next.
load_celt_grammar :- celt_grammar(CELT_GRAMMAR),
	consult(CELT_GRAMMAR).

load_user_ontologies :-
	user_ontology_extensions(ONTOLOGY_FILES),
% If any file in the User Ontology Extensions subfolder are *.txt only,
% first convert *.pl equivalents to allow CELT to read the KIF in in a
% Prolog format it can reason over.
	convert_KIF_ontologies_to_PL(ONTOLOGY_FILES),
	consult(ONTOLOGY_FILES).

celt_init :- reset_all_generated_names,reset_flags_to_defaults.

% Other possible options for use in celt_init :
% -- drt_messages_on
% -- suppress_type_info_in_generated_KIF

% celt_version(-Version_Major,-Version_Minor,-Release)
celt_version(3,b,2.65). % CELT Version 3(b), Release 2.65

:-load_CELT.                      % Loads main CELT files.

:-write_ln('To call CELT interactively call top_level/0. For other useful top-level CELT functions call more_help/0.').

more_help :-
	write_ln('Other top-level CELT functions are eng2log/1, eng2log/2, translate/2, and test_CELT/0.'),
	write_ln('E.g., eng2log("John arrives at the bank."),  eng2log("John sees the sandwich. He eats it.").'),
	write_ln('and questions... eng2log("Which dog enters the house?"),  eng2log("Does an aardvark enter the igloo?").'),
	write_ln('Translate can be used to test translation of grammatical parts sentence, query, or np:'),
	write_ln('E.g., translate(np,\'the baker who sees the dog\')'),
        write_ln('test_CELT/0 provides a systematic test of CELT installation and takes a few minutes to run some 185+ tests.').






